package app.service.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.dao.EmptyResultDataAccessException;




import app.dao.UserDao;
import app.dto.EvenFilterRequest;
import app.dto.EventFilterResponse;
import app.dto.EventResponse;
import app.dto.PaymentConfirmationRequest;
import app.dto.StatusUpdate;
import app.dto.StoreBookingRequest;
import app.dto.StoreBookingResponse;
import app.dto.StoreCategoryResponse;
import app.dto.StoreProductResponse;
import app.dto.UserResponse;
import app.dto.UserUpdateProfileRequest;
import app.entity.Event;
import app.entity.StoreBooking;
import app.entity.StoreCategory;
import app.entity.StoreProduct;
import app.entity.User;
import app.exception.AccessDeniedException;
import app.exception.BadRequestException;
import app.exception.EventNotAvailableException;
import app.exception.InsufficientQuantityException;
import app.exception.ResourceNotFoundException;
import app.exception.UserIdNotFoundException;
import app.mapper.EventFilterMapper;
import app.mapper.EventResponseFilterMapper;
import app.mapper.EventResponseMapper;
import app.mapper.UserResponseMapper;
import app.service.UserService;
import app.util.DistanceCalculator;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
    @Autowired
    private UserResponseMapper mapper;

    @Autowired
    private EventResponseMapper eventRespnseMapper;
    
    @Autowired
    private EventResponseFilterMapper eventFilterResponse;
    
    @Autowired
    private EventFilterMapper  eventFilterMapper;
    
   

    @Override
    public List<Event> getAllEvents(
            String userId,
            Double latitude,
            Double longitude,
            String location,
            double radius) {

        List<Event> event =
                userDao.getAllEvents(
                        userId,
                        latitude,
                        longitude,
                        location,
                        radius
                );

        if (event.isEmpty()) {
            throw new EventNotAvailableException(
                    "Events are not scheduled or available in the surrounding area"
            );
        }

        return event;
    }

    @Override
    public List<EventResponse> TopPopularityEvents(
            String userId,
            Double latitude,
            Double longitude,
            String location,
            double radius) {

        List<Event> events =
                userDao.TopPopularityEvent(
                        userId,
                        latitude,
                        longitude,
                        location,
                        radius
                );

        List<EventResponse> response =
                eventRespnseMapper.eventResponse(events);

        if (response.isEmpty()) {
            throw new EventNotAvailableException(
                    "Events are not scheduled or available in the surrounding area"
            );
        }

        return response;
    }

    @Override
    public List<EventResponse> weekEndEvents(
            String userId,
            Double latitude,
            Double longitude,
            String location,
            double radius) {

        List<Event> events =
                userDao.weekEndEvents(
                        userId,
                        latitude,
                        longitude,
                        location,
                        radius
                );

        List<EventResponse> response =
                eventRespnseMapper.eventResponse(events);

        if (response.isEmpty()) {
            throw new EventNotAvailableException(
                    "Events are not scheduled or available in the surrounding area"
            );
        }

        return response;
    }

    @Override
    public UserResponse getUser(String user_id) {

        try {
            User user = userDao.getUser(user_id);
            return mapper.userResponse(user);

        } catch (EmptyResultDataAccessException e) {
            throw new UserIdNotFoundException("User not found");
        }
    }

    @Override
    public String updateProfileById(
            String user_id,
            String role,
            UserUpdateProfileRequest userProfile) {

        User user = userDao.getUser(user_id);

        if (!user.getUserId().equals(user_id)
                || role.equals("VENDOR")) {

            throw new AccessDeniedException(
                    "You cannot have access to modify profile "
            );
        }

        return userDao.updateProfileById(
                user_id,
                role,
                userProfile
        );
    }

    @Override
    public String updateStatus(
            String user_id,
            String role,
            StatusUpdate status) {

        User user = userDao.getUser(user_id);

        if (!user.getUserId().equals(user_id)
                || role.equals("VENDOR")) {

            throw new AccessDeniedException(
                    "You cannot have access to modify profile "
            );
        }

        return userDao.updateStatus(
                user_id,
                role,
                status
        );
    }

    @Override
    public List<EventFilterResponse> getFilteredEvents(
            EvenFilterRequest filter) {


        List<Event> events = userDao.getActiveEvents();


        List<Event> filteredEvents =
                eventFilterMapper.filter(events, filter);


        List<EventFilterResponse> response =eventFilterResponse.response(filteredEvents);


        return response;
    }
    @Override
    public List<StoreCategoryResponse> getNearbyStoreCategories(
            double latitude,
            double longitude,
            double radius) throws BadRequestException  {
    	if (latitude < -90 || latitude > 90) {
    	    throw new BadRequestException(
    	            "Latitude must be between -90 and 90");
    	}

    	if (longitude < -180 || longitude > 180) {
    	    throw new BadRequestException(
    	            "Longitude must be between -180 and 180");
    	}

    	if (radius <= 0) {
    	    throw new BadRequestException(
    	            "Radius must be greater than 0");
    	}
    	

        List<Event> events = userDao.getActiveStoreEvents();

        List<Event> nearbyEvents = events.stream()
                .filter(event -> event.getLatitude() != null)
                .filter(event -> event.getLongitude() != null)
                .filter(event ->
                        DistanceCalculator.calculateDistance(
                                latitude,
                                longitude,
                                event.getLatitude(),
                                event.getLongitude()
                        ) <= radius
                )
                .toList();
        List<String> categoryIds = nearbyEvents.stream()
                .map(Event::getCategoryId)
                .distinct()
                .toList();
        List<StoreCategory> categories = categoryIds.stream()
                .map(categoryId -> userDao.getCategoryById(categoryId))
                .toList();
        
        List<StoreCategoryResponse> response = categories.stream()
                .map(category -> {
                    StoreCategoryResponse result = new StoreCategoryResponse();

                    result.setCategoryId(category.getCategoryId());
                    result.setCategoryName(category.getCategoryName());

                    return result;
                })
                .toList();

        return response;

       
    }
    
    @Override
    public List<Event> getStoreByCategory(String categoryId) {

        List<Event> events = userDao.getStoreByCategory(categoryId);

        if (events.isEmpty()) {
            throw new EventNotAvailableException(
                    "No stores are available for this category"
            );
        }

        return events;
    }
    @Override
    public StoreProductResponse getProductById(String productId) {

        StoreProduct product = userDao.getProductById(productId);

        StoreProductResponse response = new StoreProductResponse();

        response.setProductName(product.getProductName());
        response.setProductDescription(product.getProductDescription());
        response.setProductPrice(product.getProductPrice());
        response.setAvailableQuantity(product.getAvailableQuantity());
        response.setProductImage(product.getProductImage());

        return response;
    } 
    
   
}

   

