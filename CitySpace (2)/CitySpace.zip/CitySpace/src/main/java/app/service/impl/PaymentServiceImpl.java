package app.service.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import app.dao.BookingDao;
import app.dao.PaymentDao;
import app.dto.PaymentRequest;
import app.dto.PaymentResponse;
import app.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentDao paymentDao;
    
    @Autowired
    private BookingDao bookingDao;

    @Override
    @Transactional
    public PaymentResponse makePayment(PaymentRequest request) {

        // 1. Get booking amount from database
        BigDecimal bookingAmount =
                paymentDao.getBookingAmount(request.getBookingId());

        // 2. GST calculation
        BigDecimal gstPercentage = BigDecimal.valueOf(18);

        BigDecimal gstAmount =
                bookingAmount
                        .multiply(gstPercentage)
                        .divide(BigDecimal.valueOf(100));

        // 3. Convenience fee
        BigDecimal convenienceFee = BigDecimal.valueOf(50);

        // 4. Final payment amount
        BigDecimal totalAmount =
                bookingAmount
                        .add(gstAmount)
                        .add(convenienceFee);

        // 5. Generate payment details
        String paymentId = UUID.randomUUID().toString();

        String transactionId = UUID.randomUUID().toString();

        String paymentStatus = "SUCCESS";

        // 6. Save payment in database
        paymentDao.savePayment(
                paymentId,
                request.getBookingId(),
                bookingAmount,
                gstPercentage,
                gstAmount,
                convenienceFee,
                totalAmount,
                request.getPaymentMethod(),
                paymentStatus,
                transactionId
        );

        // 7. Prepare response
        PaymentResponse response = new PaymentResponse();

        response.setPaymentId(paymentId);
        response.setBookingId(request.getBookingId());
        response.setBookingAmount(bookingAmount);
        response.setGstAmount(gstAmount);
        response.setConvenienceFee(convenienceFee);
        response.setTotalAmount(totalAmount);
        response.setPaymentMethod(request.getPaymentMethod());
        response.setPaymentStatus(paymentStatus);
        response.setTransactionId(transactionId);
        response.setPaymentDate(LocalDateTime.now());

        return response;
    }
}