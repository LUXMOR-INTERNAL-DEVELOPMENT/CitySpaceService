package app.repository;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class PaymentRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${store.getBookingAmount}")
    private String getBookingAmount;

    @Value("${store.savePayment}")
    private String savePayment;

    public BigDecimal getBookingAmount(String bookingId) {

        return jdbcTemplate.queryForObject(
                getBookingAmount,
                new Object[] { bookingId },
                BigDecimal.class
        );
    }

    public void savePayment(
            String paymentId,
            String bookingId,
            BigDecimal bookingAmount,
            BigDecimal gstPercentage,
            BigDecimal gstAmount,
            BigDecimal convenienceFee,
            BigDecimal totalAmount,
            String paymentMethod,
            String paymentStatus,
            String transactionId) {

        jdbcTemplate.update(
                savePayment,
                paymentId,
                bookingId,
                bookingAmount,
                gstPercentage,
                gstAmount,
                convenienceFee,
                totalAmount,
                paymentMethod,
                paymentStatus,
                transactionId
        );
    }
}