package app.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import app.entity.Event;
import app.entity.StoreBooking;
import app.entity.StoreCategory;
import app.entity.StoreProduct;
import app.entity.User;
import app.mapper.EventRowMapper;
import app.mapper.StoreCategoryRowMapper;
import app.mapper.UserRowMapper;

import app.mapper.StoreProductRowMapper;

@Repository
public class UserRepository {
	
        @Autowired
	    private  JdbcTemplate jdbcTemplate;
        
        @Value("${event.getActiveEvents}")
	    private String getActiveEventsQuery;
        
        @Value("${store.getActiveStoreEvents}")
        private String getActiveStoreEventsQuery;
        
	    @Value("${user.getUserById}")
	    private String getUserByIdQuery;

	    @Value("${user.updateUser}")
	    private String updateUserQuery;
	    
	    @Value("${user.updateUserStatus}")
	    private String updateUserStatusQuery;
	    
	    @Value("${store.getCategoryById}")
	    private String getCategoryByIdQuery;
	    
	    @Value("${store.getStoreByCategory}")
	    private String getStoreByCategoryQuery;
	    
	  
	    
	    @Value("${store.getProductById}")
	    private String getProductByIdQuery;

	   
	    @Autowired
	    private UserRowMapper userRowMapper;

	    @Autowired
	    private EventRowMapper eventRowMapper;
	    
	    @Autowired
	    private StoreCategoryRowMapper storeCategoryRowMapper;
	    
	
	    
	    @Autowired
	    private StoreProductRowMapper storeProductRowMapper;


	    public List<Event> getActiveEvents() {

	        return jdbcTemplate.query(
	                getActiveEventsQuery,
	                eventRowMapper
	        );
	    }
	    
	   
	    
	   
	    public User getUserById(String user_id) {

	        return jdbcTemplate.queryForObject(
	                getUserByIdQuery,
	                userRowMapper,
	                user_id
	        );
	    }

	    public int updateUser(User user) {

	        return jdbcTemplate.update(updateUserQuery,
	                user.getUserName(),       
	                user.getEmail(),          
	                user.getPhoneno(),        
	                user.getPassword(),      
	                user.getUserLocation(),   
	                user.getUpdatedBy(),      
	                user.getUserId()         
	        );
	    }

	   public int updateUserStatus(User user) {

		    return jdbcTemplate.update(
		        updateUserStatusQuery,
		        user.getStatus(),
		        user.getUserId()
		    );
		}
	   
	   public List<Event> getActiveStoreEvents() {

		    return jdbcTemplate.query(
		            getActiveStoreEventsQuery,
		            eventRowMapper
		    );
		}
	   
	   public StoreCategory getCategoryById(String categoryId) {

		    return jdbcTemplate.queryForObject(
		            getCategoryByIdQuery,
		            storeCategoryRowMapper,
		            categoryId
		    );
		}
	   
	   public List<Event> getStoreByCategory(String categoryId) {

		    return jdbcTemplate.query(
		            getStoreByCategoryQuery,
		            eventRowMapper,
		            categoryId
		    );
		}
	   
	
		
	   
	   
	   
	 public StoreProduct getProductById(String productId) {

		    return jdbcTemplate.queryForObject(
		        getProductByIdQuery,
		        storeProductRowMapper,
		        productId
		    );
		}
	   
	
	   
	 
	}

