package app.entity;

public class CategoryTable {

}
